# -*- coding: utf-8 -*-

from datetime import datetime, date, timedelta
from odoo import api, fields, models, _


class TransferOrder(models.Model):
    _name = "transfer.order"

    date = fields.Datetime(string='Date')
    name = fields.Char()
    to_bank = fields.Char() 
    tel = fields.Char() 
    fax = fields.Char() 
    bank_account = fields.Char() 
    currency = fields.Many2one('res.currency') 
    amount = fields.Float() 
    amount_words = fields.Char(compute = "compute_amount_in_words")
    order_by = fields.Char() 
    receiving_bank = fields.Char() 
    beneficiary = fields.Many2one('res.partner') 
    swift_code = fields.Char() 
    bank_address = fields.Char() 
    payment_details = fields.Char() 
    charges = fields.Char()



    @api.depends('amount', 'currency')
    def compute_amount_in_words(self):
        if self.amount and self.currency:
            self.amount_words = self.currency.amount_to_text(self.amount)

    @api.model
    def create(self, vals):
        order = super(TransferOrder, self).create(vals)
        order.name = self.env['ir.sequence'].next_by_code('transfer.order')

        return order




class Appoaval(models.Model):
    _name = "finance.appoaval"

    @api.model
    def create(self, vals):
        app = super(Appoaval, self).create(vals)
        app.sequence = self.env['ir.sequence'].next_by_code('finance.appoaval')

        return app

    date = fields.Datetime(string='Date')
    sequence = fields.Char() 
    location = fields.Char() 
    name = fields.Char()
    payment_method = fields.Char()
    currency = fields.Many2one('res.currency')
    beneficiary = fields.Many2one('res.partner') 
    amount = fields.Float() 
    amount_words = fields.Char() 
    account_number = fields.Char() 
    cheque_number = fields.Char()  
    bank_name = fields.Char() 

    # @api.multi
    # def get_product_accounts(self, fiscal_pos=None):
    #     accounts = self._get_product_accounts()
    #     if not fiscal_pos:
    #         fiscal_pos = self.env['account.fiscal.position']
    #     return fiscal_pos.map_accounts(accounts)


