# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
{
    'name' : 'Accounting Forms',
    'version' : '1.0',
    'sequence': 4,
    'category': 'Accounting',
    'depends' : ['account'],
    'data': [
        'security/ir.model.access.csv',
        'views/transfer_order_view.xml',
        'views/approaval.xml',
        'views/transfer_order_print.xml',
        'views/approaval_print.xml'

    ],
  
    'installable': True,
    'application': True,
    'auto_install': False,
}
